function addTwoNumbers(a,b)
{
	return (a+b);
}
function faultyAddTwoNumbers(a,b)
{
	return	(a+b-1);
}

function	subtractTwoNumbers(a,b)
{
return	(a-b);
}

function	multiplyTwoNumbers(a,b)
{
return	(a*b);
}

function	divideTwoNumbers(a,b)
{
return	(a/b);
}

function checkField(objectId)
	{
		if ($("#"+objectId).val()=="")
		{
			$("#"+objectId).css({'background-color':'rgb(255,0,0)'});
		}
	}
	



